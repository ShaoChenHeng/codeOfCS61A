# scheme.py
cs61a scheme project
ummm pretty bad at readmes for projects
just wanted to upload my shit online in case i lose it later in my life 
anyways this is the final project for cs61a spring 2017 paul hilfinger 
we built a scheme interpreter. 
